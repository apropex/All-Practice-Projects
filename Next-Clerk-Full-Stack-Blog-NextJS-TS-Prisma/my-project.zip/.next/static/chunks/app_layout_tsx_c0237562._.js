(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__9d126714._.css",
  "static/chunks/node_modules_@clerk_nextjs_dist_esm_app-router_636fe540._.js",
  "static/chunks/node_modules_48542a3f._.js"
],
    source: "dynamic"
});
